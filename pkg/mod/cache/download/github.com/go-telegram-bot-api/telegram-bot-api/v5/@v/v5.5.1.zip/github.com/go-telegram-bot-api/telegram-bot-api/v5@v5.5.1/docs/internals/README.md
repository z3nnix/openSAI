# Internals

If you want to contribute to the project, here's some more information about
the internal structure of the library.
